df=read.csv(file='adult.csv', stringsAsFactors = T, header = T)
dat=df
summary(dat)
str(dat)

# 1. Remove unnecessary variables: fnlwgt, education, and relationship
dat = dat[,-c(3,4,8)] 
summary(dat)

# 2. Clean the Outliers by using IQR method
## cleaning outliers in age ##
summary(dat$age)
Q1_age = 28
Q3_age = 48
IQR_age = Q3_age - Q1_age#IQR = Q3 - Q1
IQR_age

# Find lowest value (LowerWhisker = Q1 - 1.5 * IQR_age) 
LowerW_age = Q1_age - (1.5*IQR_age)
LowerW_age

# Find upper value (UpperWhisker = Q3 + 1.5 * IQR_age)
UpperW_age = Q3_age + 1.5 * IQR_age
UpperW_age

# Find observations above 78 (as UpperW_age =78)
dat = subset(dat, age <= 78)

## Cleaning outliers in education.num ##
summary(dat$education.num)
Q1_education.num  = 9
Q3_education.num  = 12
IQR_education.num = Q3_education.num  - Q1_education.num
IQR_education.num 

# Find lowest value (LowerWhisker = Q1 - 1.5 * IQR_education.num) 
LowerW_education.num  = Q1_education.num - 1.5*IQR_education.num
LowerW_education.num 

# Find upper value: (UpperWhisker = Q3 + 1.5 * IQR_education.num)
UpperW_education.num  = Q3_education.num  + 1.5*IQR_education.num
UpperW_education.num 

# Find observations below 4.5
dat = subset(dat, education.num >= 4.5)

## Cleaning outliers in capital.gain ##
summary(dat$capital.gain)
hist(dat$capital.gain)
boxplot(dat$capital.gain) # 99999 would be a potential outlier
dat = subset(dat, capital.gain < 99999) 

# 3. Reclassifying Categorical Variables
## Change the "?" to Unknown ##
dat$occupation = gsub("?", "Unknown", dat$occupation, fixed = T )
dat$occupation =as.factor(dat$occupation)
summary(dat$occupation)

dat$workclass = gsub("?", "Unknown", dat$workclass, fixed = T )
dat$workclass =as.factor(dat$workclass)
summary(dat$workclass)

## Reclassify field values ##

## For workclass ##
# Grouping "Federal-gov" "Local-gov", and "State-gov" into "Gov"
levels(dat$workclass)
levels(dat$workclass)[c(1,2,7)] = 'Gov'
# Grouping "Self-emp-inc" and "Self-emp-not-inc" into "Self-emp"
levels(dat$workclass)
levels(dat$workclass)[4:5] = 'Self-emp'
levels(dat$workclass)

## For marital.status ##
levels(dat$marital.status)
levels(dat$marital.status)[2:4] = 'Married'

## For native.country ##
t1 = table(dat$native.country) 
prop.table(t1) 
# Since 90% records are from the US, we group the variable native.country into "non-US" and "US"
levels(dat$native.country)
levels(dat$native.country)[c(28)] = 'United-States'
levels(dat$native.country)[c(1:27,29:41)] = 'Non-U.S.'

## For occupation ##
levels(dat$occupation)
levels(dat$occupation)[c(6,8,9)] = 'Service'
levels(dat$occupation)[c(4,8)] = 'Professional/Managerial'
levels(dat$occupation)[c(1,7)] = 'Administration'

# 4. Min-Max normalization
datnorm = dat
head(datnorm)
for (i in c(1, 3, 8, 9, 10)){
  mindf = min(datnorm[,i])
  maxdf = max(datnorm[,i])
  datnorm[,i] =(datnorm[,i] - mindf)/(maxdf - mindf)
}
head(datnorm)

# 5. Creating training and test data set
# Divide the dataset into 2 portions in the ratio of 75: 25 for the training and test data set respectively.
DF=datnorm
set.seed(123)
samp = sample(1:nrow(DF),round(0.75*nrow(DF)))
str(samp)
DF.training = DF[samp,]
DF.test= DF[-samp,]
str(DF.training)
str(DF.test)

# 6. Create dummy variable
library('caret')

## DF.training - create dummy variable ##
dmy.training = dummyVars(" ~ .", data = DF.training)
training.dmy = data.frame(predict(dmy.training, newdata = DF.training))

# Dummy variables are created. We have to remove the income<=50k column 
names(training.dmy) 
# Add the original income variable into the table
#training.dmy$income = DF.training$income
training.dmy = training.dmy[-37] # Remove column 37 which is income <=50
training.dmy = training.dmy[-38] # Remove column 38 (the original income class)
names(training.dmy)[names(training.dmy) == "income..50K"] = "income.more.50k" # Rename the income>50k column
str(training.dmy) # Final check

## DF.test - create dummy variable ##
dmy.test = dummyVars(" ~ .", data = DF.test)
test.dmy = data.frame(predict(dmy.test, newdata = DF.test))

# Dummy variables are created. We have to remove the income<=50k column   
test.dmy = test.dmy[-37] # Remove column 41 which is income<=50
names(test.dmy)[names(test.dmy) == "income..50K"] = "income.more.50k" # Rename the income>50k column
names(test.dmy) # Final check

# 7. Create a matrix for model comparison
Model.Com = matrix(c(0), nrow=9, ncol=12)
rownames(Model.Com) = (c('nnet10', 'nnet5', 'neuralnet3','knn20','knn10','knn5','CART Tree', 'C4.5Tree1','*C4.5Tree1.Cost'))
colnames(Model.Com) = (c('1-True.Pos', '2-True.Neg','3-False.Pos', '4-False.Neg','5-Overall Error Rate','6-Proportion of False Pos',
                           '7-Proportion of False Neg', '8-Overall Accuracy','9-Accuracy','10-Sensitivity','11-Specificity','12-Decision Cost'))
Model.Com

### 8a. Neural Networks by using nnet ###
library(nnet)
nnet10 = nnet(income~., data=DF.training, size=10, maxit = 500) 
nnet5 = nnet(income~., data=DF.training, size=5, maxit = 500) 

# Prediction and Prediction table
estincome.nnet10 = predict(nnet10, DF.test, type = 'class')
estincome.nnet5 = predict(nnet5, DF.test, type = 'class')

tab.nnet10 = table(DF.test$income, estincome.nnet10)
tab.nnet5 = table(DF.test$income, estincome.nnet5)

### 8b. Neural Networks by using neuralnet ###
library(neuralnet)
names(training.dmy)
neuralnet3 = neuralnet(income.more.50k~., data = training.dmy, hidden=3, linear.output = F, stepmax = 1e6)

# plot the neural network
plot(neuralnet3, show.weights=TRUE)

# Prediction
estincome.neuralnet3= predict(neuralnet3, test.dmy, method='class')

# Create a variable 'pred.income' and fill with '<=50k'
pred.neuralnet3 = rep('<=50K', length(estincome.neuralnet3))

# Using a threshold of 0.5 to determine if income is >50k
pred.neuralnet3 [estincome.neuralnet3>=0.5] <- '>50K'

# Prediction table
tab.neuralnet3 = table(test.dmy$income.more.50k,pred.neuralnet3)

### 9. K-nearest Neighbor ###
library(class)
knn.training = training.dmy[-37] # Remove target variable
knn.test = test.dmy[-37]

# This code takes the income factor from the data frame and creates DF_train_labels and DF_test_labels.
DF_train_labels = DF$income[samp] # Real results
DF_test_labels = DF$income[-samp]
str(DF_train_labels)
str(DF_test_labels)

# Try different k values
estknn.20 = knn(knn.training, knn.test , DF_train_labels, k=20)
estknn.10 = knn(knn.training, knn.test , DF_train_labels, k=10)
estknn.5 = knn(knn.training, knn.test , DF_train_labels, k=5)

# Prediction table
Tab.knn20 = table(DF_test_labels,estknn.20)
Tab.knn10 = table(DF_test_labels,estknn.10)
Tab.knn5 = table(DF_test_labels,estknn.5)

### 10. Decision Tree ###
library(rpart)
library(rpart.plot)
str(DF.training)

# 10a. CART Decision Tree
Ctree1 = rpart(income~., data=DF.training, method = "class", model = TRUE,control = rpart.control(minsplit = 1000))
rpart.plot(Ctree1) #Tree with Probabilities

# Prediction
realincome = DF.test$income
estincome.Ctree1 = predict(Ctree1, DF.test, type="class")
tab.Ctree1 = table(realincome, estincome.Ctree1)
tab.Ctree1

# 10b. C4.5 Decision Tree
library(C50)
# Define x & Y
str(DF.training)
x=DF.training[-12]
y=DF.training$income

C.50tree1 = C5.0(x,y, control = C5.0Control(minCases = 100))

C5imp(C.50tree2, metric = "splits")  #check the important variables

# Prediction Table
est.C.50tree1 = predict(C.50tree1, DF.test, type='class')
Tab.C.50tree1 = table(DF.test$income, est.C.50tree1)

## 12. Misclassification cost adjustment ##
costm = matrix(c(1,2,1,1), byrow = FALSE, 2,2) #increase the false negative into 2
costm

# Create the tree
C.50tree1.cost = C5.0(x,y, costs = costm,control = C5.0Control(minCases = 100))

# Prediction Table
est.C.50tree1.cost = predict(C.50tree1.cost, DF.test, type='class')
Tab.C.50tree1.cost = table(DF.test$income, est.C.50tree1.cost)

## 11. Decision Cost Analysis
## Putting the results to the Model Comparison Table ##
# Accuracy
nnet10.accuracy = sum(diag(tab.nnet10))/sum(tab.nnet10)
nnet5.accuracy = sum(diag(tab.nnet5))/sum(tab.nnet5)
neuralnet3.accuracy = sum(diag(tab.neuralnet3))/sum(tab.neuralnet3)
knn20.accuracy = sum(diag(Tab.knn20))/sum(Tab.knn20)
knn10.accuracy = sum(diag(Tab.knn10))/sum(Tab.knn10)
knn5.accuracy = sum(diag(Tab.knn5))/sum(Tab.knn5)
Ctree1.accuracy = sum(diag(tab.Ctree1))/sum(tab.Ctree1)
C.50tree1.accuracy = sum(diag(Tab.C.50tree1))/sum(Tab.C.50tree1)
C.50tree1.cost.accuracy = sum(diag(Tab.C.50tree1.cost))/sum(Tab.C.50tree1.cost)

# Neural Networks
Model.Com[1,1] = nnet10.True.Positive = tab.nnet10[2,2]
Model.Com[1,2] = nnet10.True.Negative = tab.nnet10[1,1]
Model.Com[1,3] = nnet10.False.Positive = tab.nnet10[1,2]
Model.Com[1,4] = nnet10.False.Negative = tab.nnet10[2,1]
Model.Com[1,9] = nnet10.accuracy
Model.Com[2,1] = nnet5.True.Positive = tab.nnet5[2,2]
Model.Com[2,2] = nnet5.True.Negative = tab.nnet5[1,1]
Model.Com[2,3] = nnet5.False.Positive = tab.nnet5[1,2]
Model.Com[2,4] = nnet5.False.Negative = tab.nnet5[2,1]
Model.Com[2,9] = nnet5.accuracy
Model.Com[3,1] = neuralnet3.True.Positive = tab.neuralnet3[2,2]
Model.Com[3,2] = neuralnet3.True.Negative = tab.neuralnet3[1,1]
Model.Com[3,3] = neuralnet3.False.Positive = tab.neuralnet3[1,2]
Model.Com[3,4] = neuralnet3.False.Negative = tab.neuralnet3[2,1]
Model.Com[3,9] = neuralnet3.accuracy

# Knn
Model.Com[4,1] = knn20.True.Positive = Tab.knn20[2,2]
Model.Com[4,2] = knn20.True.Negative = Tab.knn20[1,1]
Model.Com[4,3] = knn20.False.Positive = Tab.knn20[1,2]
Model.Com[4,4] = knn20.False.Negative = Tab.knn20[2,1]
Model.Com[4,9] = knn20.accuracy
Model.Com[5,1] = knn10.True.Positive = Tab.knn10[2,2]
Model.Com[5,2] = knn10.True.Negative = Tab.knn10[1,1]
Model.Com[5,3] = knn10.False.Positive = Tab.knn10[1,2]
Model.Com[5,4] = knn10.False.Negative = Tab.knn10[2,1]
Model.Com[5,9] = knn10.accuracy
Model.Com[6,1] = knn5.True.Positive = Tab.knn5[2,2]
Model.Com[6,2] = knn5.True.Negative = Tab.knn5[1,1]
Model.Com[6,3] = knn5.False.Positive = Tab.knn5[1,2]
Model.Com[6,4] = knn5.False.Negative = Tab.knn5[2,1]
Model.Com[6,9] = knn5.accuracy

# CART tree
Model.Com[7,1] = Ctree1.True.Positive = tab.Ctree1[2,2]
Model.Com[7,2] = Ctree1.True.Negative = tab.Ctree1[1,1]
Model.Com[7,3] = Ctree1.False.Positive = tab.Ctree1[1,2]
Model.Com[7,4] = Ctree1.False.Negative = tab.Ctree1[2,1]
Model.Com[7,9] = Ctree1.accuracy

# C4.5 trees
Model.Com[8,1] = C.50tree1.True.Positive = Tab.C.50tree1[2,2]
Model.Com[8,2] = C.50tree1.True.Negative = Tab.C.50tree1[1,1]
Model.Com[8,3] = C.50tree1.False.Positive = Tab.C.50tree1[1,2]
Model.Com[8,4] = C.50tree1.False.Negative = Tab.C.50tree1[2,1]
Model.Com[8,9] = C.50tree1.accuracy

# C4.5 trees with cost adjustment
Model.Com[9,1] = C.50tree1.cost.True.Positive = Tab.C.50tree1.cost[2,2]
Model.Com[9,2] = C.50tree1.cost.True.Negative = Tab.C.50tree1.cost[1,1]
Model.Com[9,3] = C.50tree1.cost.False.Positive = Tab.C.50tree1.cost[1,2]
Model.Com[9,4] = C.50tree1.cost.False.Negative = Tab.C.50tree1.cost[2,1]
Model.Com[9,9] = C.50tree1.cost.accuracy

# Calculate the formula
Overall.Error.Rate = (Model.Com[,3] + Model.Com[,4])/(Model.Com[,1] + Model.Com[,2]+ Model.Com[,3] + Model.Com[,4])
PFP = ((Model.Com[,3])/(Model.Com[,3] + Model.Com[,1])) #6
PFN = (Model.Com[,4]/(Model.Com[,4] + Model.Com[,2])) #7
Sensitivity = Model.Com[,1]/(Model.Com[,1] + Model.Com[,4]) #10 TP/(TP + FN)
Specificity = Model.Com[,2]/(Model.Com[,3] + Model.Com[,2])  #11 TN/(FP + TN)
Decision.Cost = (Model.Com[,2]*0 )+ (Model.Com[,1]*(-200)) +(Model.Com[,4]*0) +(Model.Com[,3]*500)

# Calculate the results
Model.Com[1:9,5]=Overall.Error.Rate
Model.Com[1:9,6]=PFP 
Model.Com[1:9,7]=PFN
Model.Com[1:9,10]=Sensitivity
Model.Com[1:9,11]=Specificity
Model.Com[1:9,12]=Decision.Cost

# Calculate the overall Accuracy again
Overall.Accuracy = (1-Model.Com[,5])
Model.Com[1:9,8]=Overall.Accuracy
Model.Com
View(Model.Com)
##############################################

# This file is uploaded by @fafa-gu on GitHub on 2020-08-07. 